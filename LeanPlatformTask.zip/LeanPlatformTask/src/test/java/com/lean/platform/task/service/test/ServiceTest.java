package com.lean.platform.task.service.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.lean.platform.task.exception.SessionException;
import com.lean.platform.task.model.Client;
import com.lean.platform.task.model.Consultant;
import com.lean.platform.task.model.Document;
import com.lean.platform.task.model.Review;
import com.lean.platform.task.model.Slot;
import com.lean.platform.task.repository.ClientRepository;
import com.lean.platform.task.repository.ConsultantRepository;
import com.lean.platform.task.repository.DocumentRepository;
import com.lean.platform.task.repository.ReviewRepository;
import com.lean.platform.task.repository.SessionRepository;
import com.lean.platform.task.service.Service;

public class ServiceTest {

    @InjectMocks
    private Service service;

    @Mock
    private SessionRepository sessionRepository;

    @Mock
    private DocumentRepository documentRepository;

    @Mock
    private ReviewRepository reviewRepository;

    @Mock
    private ClientRepository clientRepository;

    @Mock
    private ConsultantRepository consultantRepository;
    
    Client client = new Client();
    Consultant consultant = new Consultant();
    Slot slot = new Slot();


    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);

        client.setId(1L);
        client.setAddress("home");
        client.setContact("122342231");
        client.setName("demo");
        client.setOccupation("student");
        
        consultant.setId(2L);
        consultant.setContact("2323232323");
        consultant.setName("Dr. Demo");
        slot.setId(1L);
        slot.setClient(client);
        slot.setConsultant(consultant);
        slot.setDateTime(LocalDateTime.now());
        }

    @Test
    public void testBookSession() {
        
        when(consultantRepository.findById(2L)).thenReturn(Optional.of(consultant));
        when(clientRepository.findById(1L)).thenReturn(Optional.of(client));
        when(sessionRepository.findAll()).thenReturn(new ArrayList<>());
        when(sessionRepository.save(slot)).thenReturn(slot);

        Slot bookedSlot = service.bookSession(slot);

        assertNotNull(bookedSlot);

        verify(sessionRepository, times(1)).save(slot);
    }

    @Test
    public void testGetConsultantUpcomingSessions() {
    	
        List<Slot> sessions = new ArrayList<>();
        sessions.add(slot);
        when(consultantRepository.findById(2L)).thenReturn(Optional.of(consultant));
        when(clientRepository.findById(1L)).thenReturn(Optional.of(client));

        when(sessionRepository.findAll()).thenReturn(sessions);

        List<Slot> upcomingSessions = service.getConsultantUpcomingSessions(2L);

        assertEquals(sessions, upcomingSessions);
    }

    @Test
    public void testGetClientSessionHistory() {

        when(clientRepository.findById(1L)).thenReturn(Optional.of(client));

        Slot slot2 = new Slot();
        slot2.setClient(client);

        List<Slot> sessionList = new ArrayList<>();
        sessionList.add(slot);
        sessionList.add(slot2);
        when(sessionRepository.findAll()).thenReturn(sessionList);

        List<Slot> clientSessions = service.getClientSessionHistory(1L);

        assertEquals(sessionList, clientSessions);
    }

    @Test
    public void testGetClientSessionHistoryClientNotFound() {
        when(clientRepository.findById(1L)).thenReturn(Optional.empty());
        assertThrows(SessionException.class, () -> service.getClientSessionHistory(1L));
    }
    
    @Test
    public void testSetListOfDocumentsByConsultantForSession() {
        Slot slot = new Slot();
        slot.setId(1L);
        Document document = new Document();
        document.setSlot(slot);

        when(sessionRepository.findById(1L)).thenReturn(Optional.of(slot));

        when(documentRepository.save(document)).thenReturn(document);

        Document savedDocument = service.setListOfDocumentsByConsultantForSession(document);

        assertNotNull(savedDocument);

        verify(sessionRepository, times(1)).findById(1L);

        verify(documentRepository, times(1)).save(document);
    }
    
    @Test
    public void testSetListOfDocumentsByConsultantForSessionSessionNotFound() {
        Slot slot = new Slot();
        slot.setId(1L);
        Document document = new Document();
        document.setSlot(slot);

        when(sessionRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(SessionException.class, () -> service.setListOfDocumentsByConsultantForSession(document));

        verify(sessionRepository, times(1)).findById(1L);

        verify(documentRepository, never()).save(document);
    }
    
    @Test
    public void testGetListOfDocumentsOfSessionForClients() {
        Document document = new Document();
        document.setId(1L);
        document.setSlot(slot);
        document.setListOfDocuments(Arrays.asList("Document1", "Document2"));
        when(documentRepository.findAll()).thenReturn(Arrays.asList(document));
        List<String> sessionDocuments = service.getListOfDocumentsOfSessionForClients(1L);
        assertNotNull(sessionDocuments);
        assertFalse(sessionDocuments.isEmpty());
        assertEquals(Arrays.asList("Document1", "Document2"), sessionDocuments);
    }

    @Test
    public void testGetListOfDocumentsOfSessionForClientsNoDocumentsFound() {
        when(documentRepository.findAll()).thenReturn(Arrays.asList());
        assertThrows(SessionException.class, () -> service.getListOfDocumentsOfSessionForClients(1L));
    }
    
    @Test
    public void testGetListOfAllDocuments() {

    	Document document1 = new Document();
        document1.setId(1L);
        document1.setSlot(slot);

        Document document2 = new Document();
        document2.setId(2L);
        document2.setSlot(slot);

        List<Document> documents = Arrays.asList(document1, document2);

        when(documentRepository.findAll()).thenReturn(documents);

        List<Document> allDocuments = service.getListOfAllDocuments();

        assertEquals(documents, allDocuments);

        verify(documentRepository, times(1)).findAll();
    }
    
    @Test
    public void testPostFeedback() {
       
        Review review = new Review();
        review.setClient(client);
        review.setConsultant(consultant);
        review.setFeedback("good");

        List<Slot> sessionList = new ArrayList<>();
        sessionList.add(slot);
        when(sessionRepository.findAll()).thenReturn(sessionList);

        when(reviewRepository.save(review)).thenReturn(review);

        Review savedReview = service.postFeedback(review);

        assertNotNull(savedReview);
        verify(sessionRepository, times(1)).findAll();
        verify(reviewRepository, times(1)).save(review);
    }
    
    @Test
    public void testPostFeedbackNoSessionFound() {
    	Review review = new Review();
        review.setClient(client);
        review.setConsultant(consultant);
        review.setFeedback("good");

        List<Slot> sessionList = new ArrayList<>();
        when(sessionRepository.findAll()).thenReturn(sessionList);

        assertThrows(SessionException.class, () -> service.postFeedback(review));

        verify(sessionRepository, times(1)).findAll();

        verify(reviewRepository, never()).save(review);
    }

    @Test
    public void testGetFeedbackForClient() {
    	Review review = new Review();
        review.setClient(client);
        review.setConsultant(consultant);
        review.setFeedback("good");

        List<Review> reviewList = new ArrayList<>();
        reviewList.add(review);
        when(reviewRepository.findAll()).thenReturn(reviewList);

        String feedback = service.getFeedbackForClient(client.getId(), consultant.getId());

        assertNotNull(feedback);
        assertEquals("good", feedback);

        verify(reviewRepository, times(1)).findAll();
    }
    
    @Test
    public void testGetFeedbackForClientNoFeedbackFound() {
        List<Review> reviewList = new ArrayList<>();

        when(reviewRepository.findAll()).thenReturn(reviewList);

        assertThrows(SessionException.class, () -> service.getFeedbackForClient(client.getId(), consultant.getId()));

        verify(reviewRepository, times(1)).findAll();
    }
    
    @Test
    public void testBookSessionSessionAlreadyExists() {

        List<Slot> sessions = new ArrayList<>();
        sessions.add(slot);
        when(consultantRepository.findById(2L)).thenReturn(Optional.of(consultant));
        when(clientRepository.findById(1L)).thenReturn(Optional.of(client));
        when(sessionRepository.findAll()).thenReturn(sessions);


        assertThrows(SessionException.class, () -> service.bookSession(slot));
        verify(sessionRepository, times(1)).findAll();
        verify(sessionRepository, never()).save(slot);
    }
}