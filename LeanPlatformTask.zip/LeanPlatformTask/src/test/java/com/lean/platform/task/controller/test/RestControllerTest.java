package com.lean.platform.task.controller.test;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lean.platform.task.model.Client;
import com.lean.platform.task.model.Consultant;
import com.lean.platform.task.model.Document;
import com.lean.platform.task.model.Review;
import com.lean.platform.task.model.Slot;
import com.lean.platform.task.service.Service;

@SpringBootTest
@AutoConfigureMockMvc
class RestControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private Service service;

    @Autowired
    private ObjectMapper objectMapper;

    Slot slot = new Slot();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        slot.setId(1L);
        slot.setClient(new Client());
        slot.setConsultant(new Consultant());
    }

    @Test
    void testBookSession() throws Exception {

        when(service.bookSession(any(Slot.class))).thenReturn(slot);

        ResultActions result = mockMvc.perform(MockMvcRequestBuilders.post("/session")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(slot)));

        result.andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1L));

        verify(service, times(1)).bookSession(any(Slot.class));
    }
    

    @Test
    void testGetConsultantUpcomingSessions() throws Exception {
        List<Slot> slots = new ArrayList<>();
        slots.add(slot);
        when(service.getConsultantUpcomingSessions(anyLong())).thenReturn(slots);

        Long consultantId = 123L;
        ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/consultant_Upcoming_Sessions/{consultantId}", consultantId)
                .contentType(MediaType.APPLICATION_JSON));

        result.andExpect(MockMvcResultMatchers.status().isAccepted())
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].id").value(1L));

        verify(service, times(1)).getConsultantUpcomingSessions(consultantId);
    }
    
    @Test
    void testGetClientSessionHistory() throws Exception {
        List<Slot> slots = new ArrayList<>();
        Slot slot1 = new Slot();
        slot1.setId(1L);
        Slot slot2 = new Slot();
        slot2.setId(2L);
        slots.add(slot1);
        slots.add(slot2);

        when(service.getClientSessionHistory(anyLong())).thenReturn(slots);

        Long clientId = 456L;
        ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/client_Sessions_History/{clientId}", clientId)
                .contentType(MediaType.APPLICATION_JSON));

        result.andExpect(MockMvcResultMatchers.status().isAccepted())
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].id").value(1L))
                .andExpect(MockMvcResultMatchers.jsonPath("$[1].id").value(2L));

        verify(service, times(1)).getClientSessionHistory(clientId);
    }
    
    @Test
    void testSelectListOfDocumentsByConsultantForSession() throws Exception {
        Document document = new Document();
        document.setId(1L);
        List<String> list = new ArrayList<>();
        list.add("Aadhar");
        list.add("Pan");
        document.setListOfDocuments(list);

        when(service.setListOfDocumentsByConsultantForSession(any(Document.class))).thenReturn(document);

        ResultActions result = mockMvc.perform(MockMvcRequestBuilders.post("/select_List_Of_Document_For_A_Session")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(document)));

        result.andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1L));

        verify(service, times(1)).setListOfDocumentsByConsultantForSession(any(Document.class));
    }
    
    @Test
    void testGetDocumentsForClient() throws Exception {
        Long sessionId = 1L;
        Document document = new Document();
        document.setId(1L);

        List<String> list = new ArrayList<>();
        list.add("Aadhar");
        list.add("Pan");
        document.setListOfDocuments(list);

        when(service.getListOfDocumentsOfSessionForClients(sessionId)).thenReturn(list);

        ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/documents_Needed_For_Session/{sessionId}", sessionId)
                .contentType(MediaType.APPLICATION_JSON));

        result.andExpect(MockMvcResultMatchers.status().isAccepted())
                .andExpect(MockMvcResultMatchers.jsonPath("$").isArray())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(list.size()))
                .andExpect(MockMvcResultMatchers.jsonPath("$[0]").value("Aadhar"))
                .andExpect(MockMvcResultMatchers.jsonPath("$[1]").value("Pan"));

        verify(service, times(1)).getListOfDocumentsOfSessionForClients(sessionId);
    }
    
    @Test
    void testGetListOfAllDocumentsForConsultant() throws Exception {
        Document document = new Document();
        document.setId(1L);

        List<String> list = new ArrayList<>();
        list.add("Aadhar");
        list.add("Pan");
        document.setListOfDocuments(list);
        
        List<Document> listOfDocs = new ArrayList<>();
        listOfDocs.add(document);

        when(service.getListOfAllDocuments()).thenReturn(listOfDocs);

        ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/all_documents")
                .contentType(MediaType.APPLICATION_JSON));

        result.andExpect(MockMvcResultMatchers.status().isAccepted()) 
                .andExpect(MockMvcResultMatchers.jsonPath("$").isArray())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(listOfDocs.size()));

        verify(service, times(1)).getListOfAllDocuments();
    }
    
    @Test
    public void testPostFeedbackByConsultantForClient() throws Exception {
        Review review = new Review();
        Client client = new Client();
        client.setId(1L);
        Consultant consultant = new Consultant();
        consultant.setId(2L);
        review.setClient(client); 
        review.setConsultant(consultant); 
        review.setFeedback("Great session!");

        Mockito.when(service.postFeedback(Mockito.any(Review.class))).thenReturn(review);

        mockMvc.perform(MockMvcRequestBuilders.post("/feedback")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"client\": {\"id\": 1}, \"consultant\": {\"id\": 2}, \"feedback\": \"Great session!\"}"))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andExpect(MockMvcResultMatchers.jsonPath("$.feedback").value("Great session!"));

        Mockito.verify(service, Mockito.times(1)).postFeedback(Mockito.any(Review.class));
    }
    
    @Test
    public void testGetFeedbackForClient() throws Exception {
        Mockito.when(service.getFeedbackForClient(Mockito.anyLong(), Mockito.anyLong())).thenReturn("Great feedback!");

        mockMvc.perform(MockMvcRequestBuilders.get("/feedback/1/2"))
                .andExpect(MockMvcResultMatchers.status().isAccepted())
                .andExpect(MockMvcResultMatchers.content().string("Great feedback!"));

        Mockito.verify(service, Mockito.times(1)).getFeedbackForClient(1L, 2L);
    }

}