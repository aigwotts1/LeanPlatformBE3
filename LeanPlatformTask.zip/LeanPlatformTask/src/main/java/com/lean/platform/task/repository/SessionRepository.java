package com.lean.platform.task.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lean.platform.task.model.Slot;

public interface SessionRepository extends JpaRepository<Slot, Long>{

}
