package com.lean.platform.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lean.platform.task.model.Client;
import com.lean.platform.task.model.Consultant;
import com.lean.platform.task.model.Document;
import com.lean.platform.task.model.Review;
import com.lean.platform.task.model.Slot;
import com.lean.platform.task.repository.ClientRepository;
import com.lean.platform.task.repository.ConsultantRepository;
import com.lean.platform.task.repository.DocumentRepository;
import com.lean.platform.task.repository.ReviewRepository;
import com.lean.platform.task.repository.SessionRepository;

@RestController
@RequestMapping("/demo")
public class DemoController {
	
	@Autowired
	DocumentRepository repo;
	
	@Autowired
	SessionRepository srepo;
	
	@Autowired
	ReviewRepository rrepo;
	
	@Autowired
	ClientRepository crepo;
	
	@Autowired
	ConsultantRepository cnrepo;

	@GetMapping("/document")
	public ResponseEntity<List<Document>> getAlldocument(){
		return new ResponseEntity<>(repo.findAll(),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/review")
	public ResponseEntity<List<Review>> getAllReview(){
		return new ResponseEntity<>(rrepo.findAll(),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/clients")
	public ResponseEntity<List<Client>> getAllClient(){
		return new ResponseEntity<>(crepo.findAll(),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/consultants")
	public ResponseEntity<List<Consultant>> getAllConsultant(){
		return new ResponseEntity<>(cnrepo.findAll(),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/session")
	public ResponseEntity<List<Slot>> getAllSlot(){
		return new ResponseEntity<>(srepo.findAll(),HttpStatus.ACCEPTED);
	}
	
	@PostMapping("/client")
	public ResponseEntity<Client> saveClient(Client client){
		return new ResponseEntity<>(crepo.save(client),HttpStatus.CREATED);
	}
	
	@PostMapping("/consultant")
	public ResponseEntity<Consultant> saveConsultant(Consultant consultant){
		return new ResponseEntity<>(cnrepo.save(consultant),HttpStatus.CREATED);
	}
}
