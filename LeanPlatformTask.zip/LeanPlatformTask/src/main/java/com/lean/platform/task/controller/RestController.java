package com.lean.platform.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.lean.platform.task.model.Document;
import com.lean.platform.task.model.Review;
import com.lean.platform.task.model.Slot;
import com.lean.platform.task.service.Service;

import jakarta.validation.constraints.Min;

@org.springframework.web.bind.annotation.RestController
public class RestController {

	@Autowired
	Service service;
	
	//1. Slot/session Book API:
	
	@PostMapping("/session")
	public ResponseEntity<Slot> bookSession(@RequestBody Slot slot){
		return new ResponseEntity<>(service.bookSession(slot),HttpStatus.CREATED);
	}
	
	//2. Session/Slot Details Api's:
	
	@GetMapping("/consultant_Upcoming_Sessions/{consultantId}")
	public ResponseEntity<List<Slot>> getConsultantUpcomingSessions(@Min(1) @PathVariable Long consultantId){
		return new ResponseEntity<>(service.getConsultantUpcomingSessions(consultantId),HttpStatus.ACCEPTED);
	}

	@GetMapping("/client_Sessions_History/{clientId}")
	public ResponseEntity<List<Slot>> getClientSessionHistory(@PathVariable  Long clientId){
		return new ResponseEntity<>(service.getClientSessionHistory(clientId),HttpStatus.ACCEPTED);
	}

	//3. PRE session activities Api's:
	
	@PostMapping("/select_List_Of_Document_For_A_Session")
	public ResponseEntity<Document> selectListOfDocumentsByConsultantForSession(@RequestBody Document document){
		return new ResponseEntity<>(service.setListOfDocumentsByConsultantForSession(document),HttpStatus.CREATED);
	}	
	
	@GetMapping("documents_Needed_For_Session/{sessionId}")
	public ResponseEntity<List<String>> getDocumentsForClient(@PathVariable Long sessionId){
		return new ResponseEntity<>(service.getListOfDocumentsOfSessionForClients(sessionId),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/all_documents")
	public ResponseEntity<List<Document>> getListOfAllDocumentsForConsultant(){
		return new ResponseEntity<>(service.getListOfAllDocuments(),HttpStatus.ACCEPTED);
	}
	
	//4. Upload feedback Api's
	
	@PostMapping("/feedback")
	public ResponseEntity<Review> postFeedbackByConsultantForClient(@RequestBody Review review){
		return new ResponseEntity<>(service.postFeedback(review),HttpStatus.CREATED);
	}
	
	@GetMapping("/feedback/{clientId}/{consultantId}")
	public ResponseEntity<String> getFeedbackForClient(@PathVariable @Min(1) Long clientId,@PathVariable @Min(1) Long consultantId){
		return new ResponseEntity<>(service.getFeedbackForClient(clientId, consultantId),HttpStatus.ACCEPTED);
	}
}