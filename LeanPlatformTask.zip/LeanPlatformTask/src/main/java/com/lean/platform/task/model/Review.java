package com.lean.platform.task.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Entity
@Data
public class Review {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@OneToOne()
	@JoinColumn(name = "client_id",referencedColumnName = "id")
	private Client client;
	@OneToOne()
	@JoinColumn(name = "consultant_id",referencedColumnName = "id")
	private Consultant consultant;
	@NotEmpty(message = "Enter Valid Feedback")
	private String feedback;
	
}