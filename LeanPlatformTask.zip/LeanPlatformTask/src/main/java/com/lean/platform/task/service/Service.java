package com.lean.platform.task.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.lean.platform.task.exception.SessionException;
import com.lean.platform.task.model.Document;
import com.lean.platform.task.model.Review;
import com.lean.platform.task.model.Slot;
import com.lean.platform.task.repository.ClientRepository;
import com.lean.platform.task.repository.ConsultantRepository;
import com.lean.platform.task.repository.DocumentRepository;
import com.lean.platform.task.repository.ReviewRepository;
import com.lean.platform.task.repository.SessionRepository;

@org.springframework.stereotype.Service
public class Service {

	@Autowired
	SessionRepository sessionRepository;
	
	@Autowired
	DocumentRepository documentRepository;
	
	@Autowired
	ReviewRepository reviewRepository;
	
	@Autowired
	ClientRepository clientRepository;
	
	@Autowired
	ConsultantRepository consultantRepository;
	
	//1.book session api's service-logic
	public Slot bookSession(Slot slot) {
		Long clientId = slot.getClient().getId();
		Long consultantId = slot.getConsultant().getId();
		isClientPresent(clientId);
		isConsultantPresent(consultantId);
		if(sessionRepository
				.findAll()
				.stream()
				.filter(session->session.getDateTime().isEqual(slot.getDateTime()) && session.getConsultant().getId().equals(slot.getConsultant().getId()))
				.findAny()
				.isPresent()) {
			throw new SessionException("Session Already Exist for Consultant at this time !!!");
		}
		return sessionRepository.save(slot);
	}
	
	//2.session details api's service-logic
	public List<Slot> getConsultantUpcomingSessions(Long consultantId){
		isConsultantPresent(consultantId);
		return sessionRepository.findAll().stream().filter(slot->slot.getConsultant().getId().equals(consultantId)).toList();
	}
	
	public List<Slot> getClientSessionHistory(Long clientId){
		isClientPresent(clientId);
		return sessionRepository.findAll().stream().filter(slot -> slot.getClient().getId().equals(clientId)).toList();	
	}
	
	//3.session activities api's service-logic
	public Document setListOfDocumentsByConsultantForSession(Document document){
		Long slotId = document.getSlot().getId();
		sessionRepository.findById(slotId).orElseThrow(()-> new SessionException("No Session Found With This Id!!!"));
		return documentRepository.save(document);	
	}
	
	public List<String> getListOfDocumentsOfSessionForClients(Long sessionId){
		Optional<Document> document = documentRepository.findAll().stream().filter(doc->doc.getSlot().getId().equals(sessionId)).findFirst();
		System.out.println(sessionId);
		if(document.isEmpty()) {
			throw new SessionException("No Required Documents yet uploaded by Consultant for this session!!!");
		}
		return document.get().getListOfDocuments();
		
	}
	
	public List<Document> getListOfAllDocuments(){
		return documentRepository.findAll();
	}
	
	//4.Upload feedback api's service-logic
	public Review postFeedback(Review review) {
		Optional<Slot> session = sessionRepository.findAll().stream().filter(slot->slot.getClient().getId().equals(review.getClient().getId())&& slot.getConsultant().getId().equals(review.getConsultant().getId())).findAny();
		if(session.isEmpty()) {
			throw new SessionException("No Session Happened Between this Client And Customer!!!");
		}
		return reviewRepository.save(review);
	}
	
	public String getFeedbackForClient(Long clientId,Long consultantId){
		Optional<Review> review = reviewRepository
				.findAll()
				.stream()
				.filter(
					feedback->feedback.getClient().getId().equals(clientId)
					&& feedback.getConsultant().getId().equals(consultantId)
					)
				.findFirst();
		if(review.isEmpty()) {
			throw new SessionException("No Feedback Yet uploaded by Consultant for such Client!!!");			
		}
		return review.get().getFeedback();
	}

	private void isConsultantPresent(Long consultantId) {
		consultantRepository.findById(consultantId).orElseThrow(()-> new SessionException("Consultant Do Not Exist With this Id"));
	}

	private void isClientPresent(Long clientId) {
		clientRepository.findById(clientId).orElseThrow(()-> new SessionException("Client Do Not Exist With this Id"));
	}
}