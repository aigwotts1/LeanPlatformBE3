package com.lean.platform.task.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lean.platform.task.model.Client;

public interface ClientRepository extends JpaRepository<Client, Long>{

}
